

const menuToggle = document.querySelector(".menu-toggle");
const navMenu = document.querySelector(".nav-menu");

menuToggle.addEventListener("click", function () {
    navMenu.classList.toggle("is-open");
    menuToggle.classList.toggle("is-open");

    const aberto = navMenu.classList.contains("is-open");
    menuToggle.setAttribute("aria-expanded", aberto);
});


const navLinks = document.querySelectorAll(".nav-menu a");

navLinks.forEach(function (link) {
    link.addEventListener("click", function () {
        navMenu.classList.remove("is-open");
        menuToggle.classList.remove("is-open");
        menuToggle.setAttribute("aria-expanded", "false");
    });
});



const modal = document.querySelector("#room-modal");
const interestButtons = document.querySelectorAll(".interest-btn");
const closeModalButtons = document.querySelectorAll("[data-close-modal]");

const modalTitle = document.querySelector("#modal-title");
const modalDescription = document.querySelector("#modal-description");
const modalCapacity = document.querySelector("#modal-capacity");
const modalAmenities = document.querySelector("#modal-amenities");

interestButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        const card = button.closest(".accommodation-card");

        const room = card.dataset.room;
        const description = card.dataset.description;
        const capacity = card.dataset.capacity;
        const amenities = card.dataset.amenities;

        modalTitle.textContent = room;
        modalDescription.textContent = description;
        modalCapacity.textContent = "Capacidade: " + capacity;

        modalAmenities.innerHTML = "";

        amenities.split(",").forEach(function (item) {

            const li = document.createElement("li");

            li.textContent = item.trim();

            modalAmenities.appendChild(li);
        });

        modal.classList.add("is-open");
        modal.setAttribute("aria-hidden", "false");
    });

});



closeModalButtons.forEach(function (button) {

    button.addEventListener("click", function () {

        modal.classList.remove("is-open");
        modal.setAttribute("aria-hidden", "true");

    });

});



document.addEventListener("keydown", function (event) {

    if (event.key === "Escape") {

        modal.classList.remove("is-open");
        modal.setAttribute("aria-hidden", "true");

    }

});



const form = document.querySelector("#contact-form");
const successMessage = document.querySelector("#form-success");

form.addEventListener("submit", function (event) {

    event.preventDefault();

    const nome = document.querySelector("#nome");
    const email = document.querySelector("#email");
    const telefone = document.querySelector("#telefone");
    const mensagem = document.querySelector("#mensagem");

    let valido = true;

    
    document.querySelectorAll(".form-group").forEach(function (grupo) {
        grupo.classList.remove("has-error");
    });

    document.querySelectorAll(".error-message").forEach(function (erro) {
        erro.textContent = "";
    });

    successMessage.textContent = "";


    
    if (nome.value.trim() === "") {

        mostrarErro(nome, "Digite seu nome.");
        valido = false;

    }


    
    if (email.value.trim() === "") {

        mostrarErro(email, "Digite seu e-mail.");
        valido = false;

    } else if (!email.value.includes("@")) {

        mostrarErro(email, "Digite um e-mail válido.");
        valido = false;

    }


    
    if (telefone.value.trim() === "") {

        mostrarErro(telefone, "Digite seu telefone.");
        valido = false;

    }


    
    if (mensagem.value.trim() === "") {

        mostrarErro(mensagem, "Digite uma mensagem.");
        valido = false;

    }


    
    if (valido) {

        successMessage.textContent =
            "Mensagem enviada com sucesso! Esta é uma simulação do projeto.";

        form.reset();

    }

});



function mostrarErro(campo, texto) {

    const grupo = campo.closest(".form-group");
    const erro = grupo.querySelector(".error-message");

    grupo.classList.add("has-error");
    erro.textContent = texto;

}



document.body.classList.add("js-ready");

const elementos = document.querySelectorAll(".reveal");

const observer = new IntersectionObserver(function (entradas) {

    entradas.forEach(function (entrada) {

        if (entrada.isIntersecting) {

            entrada.target.classList.add("is-visible");

            observer.unobserve(entrada.target);

        }

    });

}, {
    threshold: 0.15
});

elementos.forEach(function (elemento) {
    observer.observe(elemento);
});



const sections = document.querySelectorAll("main section[id]");

const observerMenu = new IntersectionObserver(function (entradas) {

    entradas.forEach(function (entrada) {

        if (entrada.isIntersecting) {

            navLinks.forEach(function (link) {
                link.classList.remove("is-active");
            });

            const linkAtivo = document.querySelector(
                '.nav-menu a[href="#' + entrada.target.id + '"]'
            );

            if (linkAtivo) {
                linkAtivo.classList.add("is-active");
            }

        }

    });

}, {
    threshold: 0.4
});

sections.forEach(function (section) {
    observerMenu.observe(section);
});
